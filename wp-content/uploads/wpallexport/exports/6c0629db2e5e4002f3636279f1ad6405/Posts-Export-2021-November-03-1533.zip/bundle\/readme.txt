Os outros dois arquivos neste zip são arquivos de exportação que contém todos os seus dados e o modelo de importação para WP All Import.

Para importar esses dados, crie uma nova importação com WP All Import e faça o upload desse arquivo zip.