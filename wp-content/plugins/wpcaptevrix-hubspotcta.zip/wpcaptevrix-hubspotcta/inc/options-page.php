<div class="wrap">

	<div id="icon-options-general" class="icon32"></div>
	<h1><?php esc_attr_e( 'HubSpot CTAs in WordPress', 'wp_admin_style' ); ?></h1>

	<div id="poststuff">

		<div id="post-body" class="metabox-holder columns-2">

			<!-- main content -->
			<div id="post-body-content">

				<div class="meta-box-sortables ui-sortable">

					<?php if(!$edit_screen): ?>
					<!-- Display Normal Screen (Add CTAs and Existing CTAs) - - - - - - - - - - -->
					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span><?php esc_attr_e( 'Add CTA', 'wp_admin_style' ); ?></span>
						</h2>

						<div class="inside">
              <form name="wpcaptevrix_hubspotcta_addcta_form" method="post" action="">
                <table class="form-table">
                	<tr>
                		<td class="row-title"><label for="wpcaptevrix_hubspotcta_name">CTA Name</label></td>
                		<td><input name="wpcaptevrix_hubspotcta_name" id="wpcaptevrix_hubspotcta_name" type="text" value="" class="regular-text" /></td>
                	</tr>
                  <tr>
                		<td class="row-title"><label for="wpcaptevrix_hubspotcta_code">Embed Code</label></td>
                		<td><textarea id="wpcaptevrix_hubspotcta_code" name="wpcaptevrix_hubspotcta_code" rows="10" style="width:100%;"></textarea></td>
                	</tr>
                  <tr>
                		<td class="row-title"><label for="wpcaptevrix_hubspotcta_img">CTA Image URL<br /><em style="font-size: .9em; font-weight: 400;">From File Manager</em></label></td>
                		<td><input name="wpcaptevrix_hubspotcta_img" id="wpcaptevrix_hubspotcta_img" type="url" value="" class="regular-text" /></td>
                	</tr>
                </table>
                <input type="hidden" name="wpcaptevrix_hubspotcta_addcta_form_submitted" value="Y" />
                <p><input class="button-primary" type="submit" name="wpcaptevrix_hubspotcta_addcta_submit" value="Add" /></p>
              </form>
            </div>
						<!-- .inside -->

					</div>
					<!-- .postbox -->

          <div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span><?php esc_attr_e( 'Existing CTAs', 'wp_admin_style' ); ?></span>
						</h2>

						<div class="inside wpcaptevrix_hubspotcta_fullwidth">
							<?php if(isset($options['cta'])): ?>
              <table class="widefat" style="width: 100%;">
                <?php
								$alternate = false;
								foreach($options['cta'] as $cta): ?>
                	<tr <?php if($alternate){ echo 'class="wpcaptevrix_hubspotcta_alternate"'; $alternate = false; } else {$alternate = true;}?>>
                		<th class="row-title"><img src="<?php echo $cta['img']; ?>" alt="<?php echo $cta['name']; ?>" class="wpcaptevrix_hubspotcta_thumb"><p style="vertical-align: middle; display: inline-block;"><?php echo '<strong>' . $cta['name'] . '</strong><br /><em>ID: ' . $cta['index'] . '</em>'; ?></p></th>
                		<th>
											<form name="wpcaptevrix_hubspotcta_edit_delete_cta_form" method="post" action="">
												<input type="hidden" name="wpcaptevrix_hubspotcta_edit_delete_cta_form_submitted" value="Y" />
												<input type="hidden" name="wpcaptevrix_hubspotcta_edit_delete_ctaindex" value="<?php echo $cta['index']; ?>" />
				                <p><input class="button-primary" type="submit" name="wpcaptevrix_hubspotcta_edit_delete_cta_submit" value="Edit" />
												<input class="button-secondary wpcaptevrix_hubspotcta_redbtn" type="submit" name="wpcaptevrix_hubspotcta_edit_delete_cta_submit" value="Delete" /></p>
				              </form>
										</th>
                	</tr>
                <?php endforeach; ?>

              </table>
							<?php else: ?>
								<p>None found. Create one above.</p>
							<?php endif; ?>
              <?php // print_r($options); ?>
            </div>
						<!-- .inside -->

					</div>
					<!-- .postbox -->

				<?php else: ?>
				<!-- Display Edit Screen - - - - - - - - - - - - - - - - - - - - -->
				<div class="postbox">

					<div class="handlediv" title="Click to toggle"><br></div>
					<!-- Toggle -->

					<h2 class="hndle"><span><?php esc_attr_e( 'Edit CTA', 'wp_admin_style' ); ?></span>
					</h2>

					<div class="inside">
						<form name="wpcaptevrix_hubspotcta_update_cta_form" method="post" action="">
							<table class="form-table">
								<tr>
									<td class="row-title"><label for="wpcaptevrix_hubspotcta_name">CTA Name</label></td>
									<td><input name="wpcaptevrix_hubspotcta_name" id="wpcaptevrix_hubspotcta_name" type="text" value="<?php echo $options['cta'][$action_cta_index]['name']; ?>" class="regular-text" /></td>
								</tr>
								<tr>
									<td class="row-title"><label for="wpcaptevrix_hubspotcta_code">Embed Code</label></td>
									<td><textarea id="wpcaptevrix_hubspotcta_code" name="wpcaptevrix_hubspotcta_code" rows="10" style="width:100%;"><?php echo stripslashes(esc_textarea($options['cta'][$action_cta_index]['code'])); ?></textarea></td>
								</tr>
								<tr>
									<td class="row-title"><label for="wpcaptevrix_hubspotcta_img">CTA Image URL<br /><em style="font-size: .9em; font-weight: 400;">From File Manager</em></label></td>
									<td><input name="wpcaptevrix_hubspotcta_img" id="wpcaptevrix_hubspotcta_img" type="url" value="<?php echo $options['cta'][$action_cta_index]['img']; ?>" class="regular-text" /></td>
								</tr>
							</table>
							<input type="hidden" name="wpcaptevrix_hubspotcta_update_cta_index" value="<?php echo $options['cta'][$action_cta_index]['index']; ?>" />
							<input type="hidden" name="wpcaptevrix_hubspotcta_update_cta_form_submitted" value="Y" />
							<p><input class="button-primary" type="submit" name="wpcaptevrix_hubspotcta_update_cta_submit" value="Update" /></p>
						</form>
					</div>
					<!-- .inside -->

				</div>
				<!-- .postbox -->

				<?php endif;?>

				</div>
				<!-- .meta-box-sortables .ui-sortable -->

			</div>
			<!-- post-body-content -->

			<!-- sidebar -->
			<div id="postbox-container-1" class="postbox-container">

				<div class="meta-box-sortables">

					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span><?php esc_attr_e(
									'Instructions', 'wp_admin_style'
								); ?></span></h2>

						<div class="inside">
							<ol>
                <li>Navigate to HubSpot's Calls-to-Action page</li>
                <li>Create a CTA or find one in the list</li>
                <li>Copy the embed code by clicking the gear icon > embed</li>
                <li>Paste the embed code in the relevant field in this plugin, along with the title and link to the image on HubSpot</li>
                <li>Click Save</li>
                <li>Insert CTA in any post or page by clicking on the <em>Add CTA</em> button</li>
								<li>CTAs can also be inserted using a shortcode as follows: [wpcaptevrix_hubspotcta id="5"]</li>
              </ol>
						</div>
						<!-- .inside -->

					</div>
					<!-- .postbox -->

				</div>
				<!-- .meta-box-sortables -->

			</div>
			<!-- #postbox-container-1 .postbox-container -->

		</div>
		<!-- #post-body .metabox-holder .columns-2 -->

		<br class="clear">
	</div>
	<!-- #poststuff -->

</div> <!-- .wrap -->
