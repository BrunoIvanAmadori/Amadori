<?php
	// Load up WordPress into our iFrame
	$absolute_path = __FILE__;
	$path_to_file = explode( 'wp-content', $absolute_path );
	$path_to_wp = $path_to_file[0];
	require_once( $path_to_wp . 'wp-load.php' );
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) )
		wp_die( 'Oops! You can\'t call this page directly.' );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style>
.wpcaptevrix_hubspotcta_half {
  width: 50%;
}
.wpcaptevrix_hubspotcta_thumb {
  max-width: 100px;
  margin-right: 15px;
  vertical-align: middle;
}

.wpcaptevrix_hubspotcta_fullwidth {
  width: 100%;
  box-sizing: border-box;
}

.wpcaptevrix_hubspotcta_alternate {
  background-color: #eee;
}

.wp-core-ui .button-secondary.wpcaptevrix_hubspotcta_redbtn {
  background: #be1e1e;
  border-color: #581414 #a51818 #a51818;
  -webkit-box-shadow: 0 1px 0 #a51818;
  box-shadow: 0 1px 0 #a51818;
  color: #fff;
  text-decoration: none;
  text-shadow: 0 -1px 1px #a51818, 1px 0 1px #a51818, 0 1px 1px #a51818, -1px 0 1px #a51818;
}

.wpcaptevrix_hubspotcta_button-primary {
    background: #0085ba;
    border-color: #0073aa #006799 #006799;
    box-shadow: 0 1px 0 #006799;
    color: #fff;
    text-decoration: none;
    text-shadow: 0 -1px 1px #006799, 1px 0 1px #006799, 0 1px 1px #006799, -1px 0 1px #006799;
    display: inline-block;
    font-size: 13px;
    margin: 0;
    cursor: pointer;
    border-width: 1px;
    border-style: solid;
    -webkit-appearance: none;
    -webkit-border-radius: 3px;
    border-radius: 3px;
    white-space: nowrap;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    margin-left: 15px;
}
</style>

</head>
<body>
<?php global $wpdb; ?>
<?php
global $wpdb;
//do something
$options = get_option('wpcaptevrix_hubspotcta');
if(isset($options['cta'])) {
  echo '<table class="widefat" style="width: 100%;">';
  $alternate = false;
  foreach($options['cta'] as $cta) {
    if($alternate){
      $class = 'wpcaptevrix_hubspotcta_alternate';
      $alternate = false;
    }
    else {
      $class = '';
      $alternate = true;
    }
    echo '<tr class="' . $class . '">';
    echo '<th class="row-title"><img src="' . $cta['img'] . '" alt="' . $cta['name'] . '" class="wpcaptevrix_hubspotcta_thumb"><p style="vertical-align: middle; display: inline-block;"><strong>' . $cta['name'] . '</strong><br /><em>ID: ' . $cta['index'] . '</em></p><p style="vertical-align: middle; display: inline-block;"><input class="button-primary wpcaptevrix_hubspotcta_button-primary" type="submit" name="' . $cta['index'] . '" value="Select" /></p></th>';
    echo '</tr>';
}
echo '</table>';
}

 ?>

<script>
  var dialogArguments = top.tinymce.activeEditor.windowManager.getParams();
  var $ = dialogArguments['jquery'];
  var editor = dialogArguments['editor'];
  var infoSubmitted = dialogArguments['infoSubmitted'];
  var context = document.getElementsByTagName("body")[0];
  $('.wpcaptevrix_hubspotcta_button-primary', context).click(function(){
    newIndex = $(this).attr('name');
    newParams = {
      editor: editor,
      jquery: $, // PASS JQUERY
      ctaindex: newIndex,
      infoSubmitted: true
    }
    top.tinymce.activeEditor.windowManager.setParams(newParams);
    top.tinymce.activeEditor.ctaindex = newIndex;
    top.tinymce.activeEditor.windowManager.close();
  });

</script>
</body>
</html>
