(function($) {
  tinymce.PluginManager.add('wpcaptevrix_hubspotcta', function(editor, url) {
    // Add a button that opens a window
    editor.addButton('wpcaptevrix_hubspotcta', {
      text: 'Add CTA',
      icon: false,
      onclick: function() {
        // Open window
        editor.windowManager.open({
          url: url + '/wpcaptevrix-hubspotcta-popup.php',
          title: 'Choose a CTA',
          width: 500,
          height: 440,
          onclose: function(){
            editor.execCommand('mceInsertContent', false, '[wpcaptevrix_hubspotcta id="' + editor.ctaindex + '"]');
          }
        },
        {
          editor: editor,
  				jquery: $, // PASS JQUERY
          infoSubmitted: false,
          ctaindex: 0
        });
      }

    });
  });
})(jQuery);
