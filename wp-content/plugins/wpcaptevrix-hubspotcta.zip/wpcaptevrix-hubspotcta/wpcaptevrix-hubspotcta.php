<?php
/*
 *	Plugin Name: HubSpot CTAs in WordPress
 *	Plugin URI: https://www.captevrix.com
 *	Description: Provides a way to more easily integrate HubSpot CTAs into wordpress pages and posts
 *	Version: 1.0
 *	Author: Kaitlyn Thul - Captevrix
 *	Author URI: https://www.captevrix.com
 *	License: GPL2
 *
*/

// Require jQuery
function wpcaptevrix_hubspotcta_load_jquery() {
    wp_enqueue_script( 'jquery' );
}
add_action( 'wp_enqueue_script', 'wpcaptevrix_hubspotcta_load_jquery' );

$plugin_url = WP_PLUGIN_URL . '/wpcaptevrix-hubspotcta';
$options = array();
$edit_screen = false;

function wpcaptevrix_hubspotcta_menu(){
  add_options_page('HubSpot CTAs in WordPress',
                    'HubSpot CTAs',
                    'manage_options',
                    'wpcaptevrix_hubspotcta',
                    'wpcaptevrix_hubspotcta_options_page');
}
add_action('admin_menu', 'wpcaptevrix_hubspotcta_menu');

function wpcaptevrix_hubspotcta_options_page(){
  global $plugins_url;
  global $options;
  global $options_index;
  global $edit_screen;
  $edit_screen = false;

  if(!current_user_can('manage_options')){
    wp_die('Sorry. You don\'t have permission to access this page');
  }

  // Process Form
  if(isset($_POST['wpcaptevrix_hubspotcta_addcta_form_submitted'])) {
    $options = get_option('wpcaptevrix_hubspotcta');
    if($options == ''){
      $options['cta-index'] = 0;
    }
    $cta_index = $options['cta-index'];
    $options['cta'][$cta_index]['index'] = $cta_index;
    $options['cta'][$cta_index]['name'] = $_POST['wpcaptevrix_hubspotcta_name'];
    $options['cta'][$cta_index]['code'] = $_POST['wpcaptevrix_hubspotcta_code'];
    $options['cta'][$cta_index]['img'] = $_POST['wpcaptevrix_hubspotcta_img'];
    $options['cta-index']++;
    update_option('wpcaptevrix_hubspotcta', $options);
    echo '<div class="notice notice-success is-dismissible"><p>' . $options['cta'][$cta_index]['name'] . ' has been added.</p></div>';

  }
  elseif(isset($_POST['wpcaptevrix_hubspotcta_edit_delete_cta_form_submitted'])){
    $action_type = $_POST['wpcaptevrix_hubspotcta_edit_delete_cta_submit'];
    $action_cta_index = $_POST['wpcaptevrix_hubspotcta_edit_delete_ctaindex'];
    $options = get_option('wpcaptevrix_hubspotcta');
    if($action_type == "Edit"){
      // Trigger Edit Screen
      $edit_screen = true;
    }
    elseif($action_type == "Delete"){
      // Delete CTA
      $action_cta_index_name = $options['cta'][$action_cta_index]['name'];
      unset($options['cta'][$action_cta_index]);
      update_option('wpcaptevrix_hubspotcta', $options);
      echo '<div class="notice notice-success is-dismissible"><p>' . $action_cta_index_name . ' has been deleted.</p></div>';
    }
  }
  elseif(isset($_POST['wpcaptevrix_hubspotcta_update_cta_form_submitted'])){
    $options = get_option('wpcaptevrix_hubspotcta');
    $cta_index = $_POST['wpcaptevrix_hubspotcta_update_cta_index'];
    $options['cta'][$cta_index]['name'] = $_POST['wpcaptevrix_hubspotcta_name'];
    $options['cta'][$cta_index]['code'] = $_POST['wpcaptevrix_hubspotcta_code'];
    $options['cta'][$cta_index]['img'] = $_POST['wpcaptevrix_hubspotcta_img'];
    update_option('wpcaptevrix_hubspotcta', $options);
    echo '<div class="notice notice-success is-dismissible"><p>' . $options['cta'][$cta_index]['name'] . ' has been updated.</p></div>';
  }

  // Get options
  $options = get_option('wpcaptevrix_hubspotcta');

  // Options Page Content
  require('inc/options-page.php');
}

function wpcaptevrix_hubspotcta_styles() {
  wp_enqueue_style('wpcaptevrix_hubspotcta_styles',
                    plugins_url('wpcaptevrix-hubspotcta/wpcaptevrix-hubspotcta.css'));
}
add_action('admin_head', 'wpcaptevrix_hubspotcta_styles');

/* ------------------ Shortcode Section ---------------------- */

function wpcaptevrix_hubspotcta_shortcode($atts){
  extract(shortcode_atts(array(
    'id' => '0'
  ), $atts, 'multilink'));
  $index = esc_html($id);
  $options = get_option('wpcaptevrix_hubspotcta');
  if(isset($options['cta'][$index]['code'])){
    $embed_code = stripslashes($options['cta'][$index]['code']);
    return $embed_code;
  }
  else {
    return '';
  }
}
add_shortcode('wpcaptevrix_hubspotcta', 'wpcaptevrix_hubspotcta_shortcode');

/* ------------------ Add TinyMCE Plugin ---------------------- */

// add new buttons
function wpcaptevrix_hubspotcta_register_buttons( $buttons ) {
   array_push( $buttons, 'separator', 'wpcaptevrix_hubspotcta' );
   return $buttons;
}
add_filter( 'mce_buttons', 'wpcaptevrix_hubspotcta_register_buttons' );

// Load the TinyMCE plugin : editor_plugin.js (wp2.5)
function wpcaptevrix_hubspotcta_register_tinymce_javascript( $plugin_array ) {
   $plugin_array['wpcaptevrix_hubspotcta'] = plugins_url( '/tinymce-button/wpcaptevrix-hubspotcta.js',__FILE__ );
   return $plugin_array;
}
add_filter( 'mce_external_plugins', 'wpcaptevrix_hubspotcta_register_tinymce_javascript' );

?>
